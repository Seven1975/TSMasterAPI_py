import setuptools

setuptools.setup(
    name="TSMasterAPI",
    version="1.0.2",
    author="Seven",
    author_email="heping.shi@tosunai.cn",
    description="python package for TsMaster.dll",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
